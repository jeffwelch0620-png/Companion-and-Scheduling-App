# @jmax/ui

The shared component library for the JMAX apps (Inventory and Companion). Theme **Option B**: Companion's blue JayMax look with one accent colour per store.

- Plain CSS on `--jm-*` variables, classes prefixed `jm-`. No Tailwind inside, so it works with Tailwind 3 and 4.
- React 19 + TypeScript, Radix primitives for focus and keyboard handling, icons from `lucide-react` (peer dependency).
- ESM + `.d.ts`, with a `"use client"` banner for React Server Component builds.

Spec: *JMAX UI Library: Build Spec* (Claude Doc). Fixtures use invented names only (Casey M., Jordan P., Riley T., Valley Produce Co., Ridge Dairy, Summit Foodservice).

## Install (tarball, v0.x)

Download `jmax-ui-<version>.tgz` from the GitHub Release, commit it to the app as `vendor/jmax-ui-<version>.tgz`, then:

```json
"dependencies": {
  "@jmax/ui": "file:vendor/jmax-ui-0.1.0.tgz",
  "lucide-react": ">=0.400.0"
}
```

Import the CSS once, at the root of the app:

```js
import "@jmax/ui/styles.css"; // tokens + every component
```

Load the Inter font in the app (400–800). The library only names it.

### Exports

| Path | What |
| --- | --- |
| `@jmax/ui` | components and types |
| `@jmax/ui/styles.css` | tokens + component CSS |
| `@jmax/ui/tokens.css` | tokens only |
| `@jmax/ui/tokens.json` | `{ light, dark, stores, scale }` resolved values |
| `@jmax/ui/tailwind-preset` | Tailwind 3 preset (`bg-jm-surface`, `text-jm-ink`, `rounded-jm-md`, …) |
| `@jmax/ui/tailwind-v4.css` | Tailwind 4 `@theme inline` block with the same names |

```js
// Tailwind 3 (Inventory) – tailwind.config.js
module.exports = { presets: [require("@jmax/ui/tailwind-preset")], /* … */ };
```

```css
/* Tailwind 4 (Companion) – globals.css */
@import "tailwindcss";
@import "@jmax/ui/tailwind-v4.css";
```

The Tailwind colours are CSS variables, so opacity modifiers such as `bg-jm-accent/50` do not work.

## Theme and store

Two attributes, normally on `<html>`:

- `data-jm-theme="light" | "dark"` (light is the default)
- `data-jm-store="owner" | "berts" | "rudds" | "papa" | "bulk"` (owner pages use the brand blue)

`<JmaxTheme>` sets them from React; plain attributes work too (for example in a server-rendered `<html>` tag). For a scoped preview, put both attributes on the same element, or use `scope="element"`.

Tokens live in the `jm-tokens` cascade layer. Any plain rule in the app (for example Inventory's phase 1 "today's values") wins over them whatever the import order.

| Store | Accent (light) | Accent (dark) |
| --- | --- | --- |
| owner / Bert's | `#1258B9` | `#6EA4F0` |
| Rudd's | `#985027` | `#E0915F` |
| Papa Leoni's | `#356344` | `#7DBB8F` |
| Bulk | `#834565` | `#CC8BAE` |

`--jm-store-<id>` always holds every store's mark colour, so owner pages can show all of them.

## Components

Every component accepts `className` and passes native props through. Interactive ones show a 3 px focus ring and work by keyboard.

### JmaxTheme
```tsx
<JmaxTheme store="rudds" mode="light">{app}</JmaxTheme>
```

### AppShell
```tsx
<AppShell
  layout="side"                       // or "top" for the Option B header
  nav={[
    { items: [{ id: "home", label: "Overview", icon: <Home /> }] },
    { group: "Daily", items: [{ id: "counts", label: "Counts", icon: <ClipboardCheck />, badge: 3 }] },
  ]}
  activeId={tab}
  onNavigate={(item) => setTab(item.id)}   // items with href render links; pass linkComponent={Link} for a router
  stores={[{ id: "owner", label: "All stores" }, { id: "rudds", label: "Rudd's" }]}
  store={store}
  onStoreChange={setStore}
  user={{ id: userId, name: "Casey M.", sub: "Manager" }}
>
  {page}
</AppShell>
```
Side layout: 248 px sidebar that folds to a 72 px icon strip (group headers become dividers, labels show on hover/focus, badges stay on icons). The collapsed state is remembered per `user.id` in localStorage (`storageKey={false}` turns that off). Under 860 px both layouts become a phone bar with a slide-out menu.

### PageHeader
```tsx
<PageHeader eyebrow="Rudd's · Evening count" title="Walk-in" description="Count what is on the shelf." actions={<Button>Submit</Button>} />
```

### Button
```tsx
<Button variant="primary" size="md" icon={<Plus />}>Add item</Button>
<Button size="lg" fullWidth loading>Sending</Button>
```
Variants `primary | secondary | ghost | danger`; sizes `sm | md | lg` (lg = 52 px phone action).

### IconButton
```tsx
<IconButton label="Edit Romaine hearts" icon={<Pencil />} variant="ghost" />
```
`label` is required and becomes the accessible name.

### Field, Input, NumberInput, Textarea, Select
```tsx
<Field label="On hand" hint="Cases on the shelf" error={err} required>
  <NumberInput unit="case" value={v} onChange={(e) => setV(e.target.value)} />
</Field>
<Field label="Supplier">
  <Select options={[{ value: "ridge", label: "Ridge Dairy" }]} placeholder="Choose" defaultValue="" />
</Field>
```
`Field` wires `id`, `aria-describedby`, `aria-invalid` and `required` into the control inside it. `NumberInput` opens the decimal keypad, right-aligns and uses tabular figures.

### Stepper
```tsx
<Stepper label="Romaine on hand" unit="case" value={n} onChange={setN} step={0.5} size="lg" />
```
− / value / +; arrow keys step; 30 px desktop, 48 px phone.

### CheckRow
```tsx
<CheckRow checked={done} onCheckedChange={setDone} label="Wipe down the line" hint="Before close" trailing={<IconButton label="Add photo" icon={<Camera />} />} />
```
The whole row toggles; it is exposed as a checkbox (Space / Enter).

### Card
```tsx
<Card eyebrow="Ridge Dairy" title="Delivery check" actions={<Button size="sm">Open</Button>} accentRule="rudds">…</Card>
```
`tone`: `default | ok | warn | bad | info | accent`. `accentRule`: `true` (current accent) or a store id. `flush` removes body padding for tables.

### MetricTile
```tsx
<MetricTile label="Short of par" value="5" sub="2 at Rudd's" subTone="warn" />
```

### StatusChip
```tsx
<StatusChip tone="bad" dot>Reported, check it</StatusChip>
```
The words always say what happened; colour is never the only signal.

### FilterChips
```tsx
<FilterChips label="Filter items" options={[{ id: "all", label: "All", count: 7 }]} value={f} onChange={setF} />
```

### StoreMark
```tsx
<StoreMark store="papa" />            {/* decorative */}
<StoreMark store="papa" label="Papa Leoni's" />
```

### DataTable
```tsx
<Card title="Evening count" flush>
  <DataTable
    caption="Evening count"
    rowKey="id"
    columns={[
      { key: "item", header: "Item" },
      { key: "onHand", header: "On hand", align: "right" },
      { key: "status", header: "Status", render: (r) => <StatusChip tone="warn">Short {r.par - r.onHand}</StatusChip> },
    ]}
    groups={[{ id: "walk-in", title: "Walk-in", meta: "4 items", rows }]}   // or rows={rows}
    rowActions={(r) => <IconButton size="sm" variant="ghost" label={`Edit ${r.item}`} icon={<Pencil />} />}
    stickyHeader
    density="compact"
    empty={<EmptyState title="No items counted yet" />}
  />
</Card>
```
Scrolls sideways inside its card (the scroll area is focusable); group rows on `surface-2`; uppercase 11.5 px headers. Set `--jm-table-max-height` to change the sticky-header height.

### StepTabs
```tsx
<StepTabs label="Count zones" steps={[{ id: "walk-in", label: "Walk-in", progress: 100, done: true, meta: "4 of 4" }]} value={zone} onChange={setZone} />
```

### ProgressBar
```tsx
<ProgressBar label="Prep tasks" value={12} max={18} />
```

### StickyActionBar
```tsx
<StickyActionBar summary="5 of 7 counted" actions={<><Button variant="secondary">Save draft</Button><Button>Submit</Button></>} />
```

### EmptyState
```tsx
<EmptyState icon={<Inbox />} title="No orders waiting" description="Submit a count first." action={<Button>Start a count</Button>} />
```

### TaskCard
```tsx
<TaskCard title="Closing checklist" sub="Riley T. · due 10 pm" status={<StatusChip tone="info">1 of 2 done</StatusChip>} defaultExpanded>
  <CheckRow … />
</TaskCard>
```

### Dialog
```tsx
<Dialog title="Change par level" trigger={<Button variant="secondary">Change par</Button>}
  footer={<><DialogClose asChild><Button variant="secondary">Cancel</Button></DialogClose><Button>Save</Button></>}>
  …
</Dialog>
```

### Sheet
```tsx
<Sheet title="Report a problem" side="bottom" trigger={<Button>Report</Button>}>…</Sheet>
```

### Toast
```tsx
<ToastProvider>{app}</ToastProvider>
// anywhere below:
const toast = useToast();
toast({ title: "Count submitted", description: "Walk-in · 7 items", tone: "ok" });
```
Replaces sonner in Inventory over time.

## Develop

```bash
npm ci
npm run storybook        # http://localhost:6006, stories under JMAX/<Group>/<Component>
npm test                 # Vitest + Testing Library, and axe-core on every story
npm run contrast         # every text/background token pair, fails under 4.5:1
npm run build            # dist/
npm run release          # all checks + .release/jmax-ui-<version>.tgz
```

`src/tokens/tokens.css` is the source of truth; `npm run tokens` regenerates `tokens.json` and the Tailwind 4 theme from it.

Every component has stories for light and dark × owner / Bert's / Rudd's / Papa Leoni's (the `Themes` story; overlays use per-story globals), tests, and an axe check. Colour contrast is checked by the script rather than axe, because tests run in jsdom.

## Release

1. Bump `version` in `package.json` and add a `## <version>` section to `CHANGELOG.md`.
2. Merge to `main`, then on a clean `main`: `bash scripts/pack-release.sh --publish` (tags `v<version>`, creates the GitHub Release with the `.tgz` and its sha256).
3. One PR per app, titled `chore(ui): @jmax/ui vX.Y.Z`, that replaces `vendor/jmax-ui-*.tgz`.
