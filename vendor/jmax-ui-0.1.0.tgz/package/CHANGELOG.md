# Changelog

Semantic versions. While on 0.x, breaking changes only land in minor versions and are listed here.

## 0.1.0

First release of the shared JMAX component library (theme Option B).

- **Tokens:** `--jm-*` variables for light and dark, store accents for owner, Bert's (#1258B9), Rudd's (#985027), Papa Leoni's (#356344) and Bulk (#834565), switched by `data-jm-theme` / `data-jm-store`. Light is the default. Tokens sit in the `jm-tokens` cascade layer so an app can override them with a plain rule.
- **Adapters:** `@jmax/ui/tailwind-preset` (Tailwind 3) and `@jmax/ui/tailwind-v4.css` (Tailwind 4 `@theme inline`), both pointing at the variables. `tokens.json` for tooling.
- **Components:** JmaxTheme, AppShell (side layout with 248 px / 72 px collapsible sidebar, top layout, phone slide-out menu, collapse remembered per user), PageHeader, Button, IconButton, Field, Input, NumberInput, Textarea, Select, Stepper, CheckRow, Card, MetricTile, StatusChip, FilterChips, StoreMark, DataTable, StepTabs, ProgressBar, StickyActionBar, EmptyState, TaskCard, Dialog, Sheet, Toast (`ToastProvider` + `useToast`).
- **Checks:** `scripts/contrast-check.mjs` (603 text pairs, all ≥ 4.5:1), Vitest + Testing Library tests, axe-core on every story, Storybook 8.
- **Not yet:** Playwright screenshot baselines per story (planned for 0.1.x). Charts, date picker and rich text are out of scope for 0.1.
